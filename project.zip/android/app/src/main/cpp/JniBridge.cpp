#include <jni.h>
#include <string>
#include "../../../../core/network/KgzClient.h"

static KgzClient* g_pKgzClient = nullptr;

extern "C" JNIEXPORT void JNICALL
Java_com_kgz_mobile_client_NativeEngine_startNetworkClient(JNIEnv* env, jobject thiz, jstring ip, jint port) {
    const char* nativeIp = env->GetStringUTFChars(ip, nullptr);
    
    if (!g_pKgzClient) {
        g_pKgzClient = new KgzClient();
    }
    
    g_pKgzClient->SetupConnection(nativeIp, port);
    
    env->ReleaseStringUTFChars(ip, nativeIp);
}

extern "C" JNIEXPORT void JNICALL
Java_com_kgz_mobile_client_NativeEngine_processClientFrame(JNIEnv* env, jobject thiz) {
    if (g_pKgzClient) {
        g_pKgzClient->Pulse(); // Опрос сетевых пакетов каждый кадр игры
    }
}

