package com.kgz.mobile.client

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {

    private val gameLoopExecutor = Executors.newSingleThreadScheduledExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Инициализируем сетевое подключение к серверу по умолчанию
        NativeEngine.startNetworkClient("188.127.241.74", 4170)

        // Запуск игрового цикла (60 раз в секунду / каждые 16 мс) для обработки пакетов
        gameLoopExecutor.scheduleAtFixedRate({
            NativeEngine.processClientFrame()
        }, 0, 16, TimeUnit.MILLISECONDS)

        setContent {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = Color.Transparent // Позволяет видеть текстуры игры под UI слоем
            ) {
                // Сюда позже добавим HUD слой
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        gameLoopExecutor.shutdown()
    }
}