package com.kgz.mobile.client.hud

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun GameHud(
    hp: Int,
    armor: Int,
    money: Int,
    ping: Int,
    fps: Int
) {
    Box(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        // Верхний правый угол: Деньги, FPS, Ping
        Column(
            modifier = Modifier.align(Alignment.TopEnd),
            horizontalAlignment = Alignment.End
        ) {
            Text(
                text = "$$money",
                color = Color(0xFF00FF66),
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(text = "FPS: $fps", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
                Text(text = "PING: $ping", color = Color(0xFF00FFFF), fontSize = 12.sp)
            }
        }

        // Нижний левый угол: Полоски HP и Брони поверх миникарты (кастомный контейнер)
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .width(160.dp)
                .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                .padding(6.dp)
        ) {
            // Полоска здоровья
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .background(Color(0xFF330000), RoundedCornerShape(2.dp))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(fraction = (hp / 100f).coerceIn(0f, 1f))
                        .background(Color(0xFFFF0033))
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            // Полоска брони
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .background(Color(0xFF222222), RoundedCornerShape(2.dp))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(fraction = (armor / 100f).coerceIn(0f, 1f))
                        .background(Color(0xFF00AAFF))
                )
            }
        }
    }
}
