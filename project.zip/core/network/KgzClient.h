#pragma once

#include <string>

class KgzClient {
private:
    std::string serverIP;
    int serverPort;
    bool isRunning;
    void* rakPeer; // Указатель на RakPeerInterface без затягивания лишних хедеров

public:
    KgzClient();
    ~KgzClient();

    void SetupConnection(const std::string& ip, int port);
    void Pulse();
    void SendPacket(unsigned char packetID, const char* data, int length);
    bool IsConnected() const { return isRunning; }
};

