#pragma once

#pragma pack(push, 1)

enum KgzPackets {
    ID_KGZ_CONNECTION_READY = 200,
    ID_KGZ_AUTH_REQUEST,
    ID_KGZ_PLAYER_SYNC,
    ID_KGZ_VEHICLE_SYNC
};

// Структура синхронизации игрока пешком
struct OnFootSyncData {
    uint16_t lrAnalog;
    uint16_t udAnalog;
    uint16_t keys;
    float position[3];
    float quaternion[4];
    uint8_t health;
    uint8_t armor;
    uint8_t weaponID;
    float velocity[3];
};

// Структура синхронизации автомобиля (критично для BMW M5 F90 и дрифта)
struct InCarSyncData {
    uint16_t vehicleID;
    uint16_t lrAnalog;
    uint16_t udAnalog;
    uint16_t keys;
    float quaternion[4];
    float position[3];
    float velocity[3];
    float vehicleHealth;
    uint8_t playerHealth;
    uint8_t armor;
};

#pragma pack(pop)

