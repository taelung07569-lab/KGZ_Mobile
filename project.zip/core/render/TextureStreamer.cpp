#include <GLES3/gl3.h>
#include <android/log.h>
#include <vector>

#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "KGZ_RENDER", __VA_ARGS__)

class TextureStreamer {
public:
    // Асинхронное создание текстуры из сырых пикселей TXD архива
    static GLuint UploadTextureAsync(const uint8_t* pixelData, int width, int height, GLenum format) {
        GLuint textureId;
        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);

        // Настройка параметров фильтрации для мобильных GPU (Adreno/Mali)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

        // Загрузка текстуры
        glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, pixelData);
        glGenerateMipmap(GL_TEXTURE_2D);

        if (glGetError() != GL_NO_ERROR) {
            LOGE("Failed to upload texture into GPU Memory");
            return 0;
        }

        glBindTexture(GL_TEXTURE_2D, 0);
        return textureId;
    }
};

};

