package com.kgz.mobile.launcher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class LauncherActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LauncherMainScreen(onStartGame = { nickname ->
                // Логика передачи никнейма и запуск MainActivity игрового клиента
                val intent = Intent().setClassName("com.kgz.mobile.client", "com.kgz.mobile.client.MainActivity")
                intent.putExtra("PLAYER_NICKNAME", nickname)
                startActivity(intent)
            })
        }
    }
}

@Composable
fun LauncherMainScreen(onStartGame: (String) -> Unit) {
    var nickname by remember { mutableStateOf("") }
    var statusText by remember { mutableStateOf("Ожидание проверки обновлений...") }
    var progress by remember { mutableStateOf(0f) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF080810))
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("KGZ MOBILE", color = Color(0xFFBD00FF), fontSize = 36.sp, fontWeight = FontWeight.Bold)
        Text("СЕРВЕР: 188.127.241.74:4170", color = Color.Gray, fontSize = 14.sp)
        
        Spacer(modifier = Modifier.height(40.dp))

        OutlinedTextField(
            value = nickname,
            onValueChange = { nickname = it },
            label = { Text("Введите ваш ник (Name_Surname)") },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Color(0xFF00FFCC),
                unfocusedBorderColor = Color.Gray,
                focusedLabelColor = Color(0xFF00FFCC),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(20.dp))

        Text(statusText, color = Color.White, fontSize = 14.sp)
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.fillMaxWidth().height(6.dp).padding(vertical = 4.dp),
            color = Color(0xFF00FFCC),
            trackColor = Color.DarkGray,
        )

        Spacer(modifier = Modifier.height(30.dp))

        Button(
            onClick = {
                statusText = "Проверка файлов..."
                UpdateManager.checkAndDownloadUpdates(
                    onProgress = { p -> progress = p },
                    onComplete = {
                        statusText = "Все файлы обновлены! Запуск..."
                        onStartGame(nickname)
                    }
                )
            },
            modifier = Modifier.fillMaxWidth().height(55.dp),
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBD00FF))
        ) {
            Text("ИГРАТЬ", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}